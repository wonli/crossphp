<?php
/**
 * @author wonli <wonli@live.com>
 */
namespace app\api\views;

use Cross\MVC\View;

/**
 * @author wonli <wonli@live.com>
 * Class ApiView
 * @package app\api\views
 */
class ApiView extends View
{

}
