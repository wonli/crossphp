<?php
/**
 * @author wonli <wonli@live.com>
 * WebView.php
 */

namespace app\web\views;


use Cross\MVC\View;

/**
 * @author wonli <wonli@live.com>
 * Class WebView
 * @package app\web\views
 */
class WebView extends View
{

}
