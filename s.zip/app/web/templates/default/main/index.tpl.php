<div class="jumbotron" style="background:#fff;border-bottom:1px solid #f5f5f5">
    <div class="container">
        <h1>Hello World</h1>
        <p>OOP，Layer，注释配置，双向智能别名，PSR，Composer</p>
        <p>
            <a class="btn btn-primary btn-lg" href="//document.crossphp.com" target="_blank" role="button">框架文档</a>
            <a class="btn btn-default btn-lg" href="//document.crossphp.com/skeleton/" target="_blank" role="button">skeleton文档</a>
        </p>
    </div>
</div>

<div class="container">
    <a href="//www.crossphp.com/" target="_blank" title="crossphp.com">CrossPHP</a>
    <?php printf('v%s', $data['version']); ?>
</div>
