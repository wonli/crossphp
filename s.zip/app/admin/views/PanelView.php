<?php
/**
 * @author wonli <wonli@live.com>
 */

namespace app\admin\views;

/**
 * @author wonli <wonli@live.com>
 *
 * Class PanelView
 * @package app\admin\views
 */
class PanelView extends AdminView
{
    function index(array $data = array())
    {

    }
}
