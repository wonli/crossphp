<div class="box">
    <div class="box-header">
        <a class="btn btn-primary" href="<?= $this->url('doc:action') ?>">添加文档</a>
    </div>

    <div class="box-body">
        <?= $data->render() ?>
    </div>

</div>