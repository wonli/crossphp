<div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            请将JSON代码粘贴至输入框，将会自动生成对应的类或结构。
        </div>
        <div class="modal-body">
            <form method="post">
                <div class="form-group">
                    <label for=""></label>
                    <textarea class="form-control" name="json" id="" cols="30" rows="10"></textarea>
                </div>

                <button type="submit" class="btn btn-primary">提交</button>
            </form>
        </div>
    </div>
</div>
<?php
/**
 * @author wonli <wonli@live.com>
 * Date: 2019/3/25
 */