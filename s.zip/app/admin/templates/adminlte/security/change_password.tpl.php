<form class="form-horizontal" action="" method="post">
    <div class="box">
        <div class="box-body">
            <div class="form-group">
                <label for="oriPassword" class="col-sm-2 col-md-2 col-lg-1 control-label">原密码</label>

                <div class="col-sm-6 col-md-4 col-lg-3">
                    <input type="password" class="form-control" name="op" id="oriPassword" placeholder="原密码">
                </div>
            </div>

            <div class="form-group">
                <label for="password" class="col-sm-2 col-md-2 col-lg-1 control-label">新密码</label>

                <div class="col-sm-6 col-md-4 col-lg-3">
                    <input type="password" class="form-control" name="np1" id="password" placeholder="新密码">
                </div>
            </div>
            <div class="form-group">
                <label for="repeatPassword" class="col-sm-2 col-md-2 col-lg-1 control-label">重复密码</label>

                <div class="col-sm-6 col-md-4 col-lg-3">
                    <input type="password" class="form-control" name="np2" id="repeatPassword" placeholder="重复密码">
                </div>
            </div>
        </div>
        <div class="box-footer">
            <div class="form-group">
                <div class="col-sm-offset-2 col-md-offset-2 col-lg-offset-1 col-sm-10">
                    <button type="submit" class="btn btn-primary">提交</button>
                </div>
            </div>
        </div>
    </div>
</form>
