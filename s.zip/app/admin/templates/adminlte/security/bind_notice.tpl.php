<div class="callout callout-danger">
    <h4>密保卡已绑定</h4>
    <p>
        登录时将验证安全码，请下载密保卡图片并妥善保存（如不需要此功能，请解绑）。
    </p>
</div>
