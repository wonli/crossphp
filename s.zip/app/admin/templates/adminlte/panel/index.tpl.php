<div class="box">
    <div class="box-header">

    </div>
    <div class="box-body">

    </div>
</div>