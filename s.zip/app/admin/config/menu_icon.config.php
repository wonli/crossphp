<?php
/**
 * @author wonli <wonli@live.com>
 * menu_icon.config.php
 */
return array(
    'adminlte' => array(
        'panel' =>  'fa fa-dashboard',
        'security'  =>  'fa fa-shield',
        'acl'   =>  'fa fa-wrench',
        'doc' => 'fa fa-file-text-o',
    )
);
