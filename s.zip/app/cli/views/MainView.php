<?php
namespace app\cli\views;

use Cross\MVC\View;

/**
 * @author wonli <wonli@live.com>
 * MainView.php
 */
class MainView extends View
{

}
