<?php
/**
 * @author wonli <wonli@live.com>
 * skeleton
 */
namespace app\cli\controllers;

/**
 * @author wonli <wonli@live.com>
 * Class Main
 * @package app\cli\controllers
 */
class Main extends Cli
{
    function index()
    {
        echo 'Cross CLI!';
    }
}
