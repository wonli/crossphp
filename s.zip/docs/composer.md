###使用composer安装

进入cmd命令行模式下,使用[composer](https://getcomposer.org/ "composer")安装依赖

	cd skeleton
	composer install

如果已经安装过,要更新到最新版,请执行以下命令

	cd skeleton
	composer clear
	composer update