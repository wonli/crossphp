<?php
/**
 * @author wonli <wonli@live.com>
 */
require __DIR__ . '/../../crossboot.php';
Cross\Core\Delegate::loadApp('api')->run();
